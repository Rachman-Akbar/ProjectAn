<?php

namespace App\Http\Controllers;

use App\Http\Requests\UserRequest;
use App\Http\Resources\UserResource;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class UserController extends Controller
{
    public function index(Request $request): AnonymousResourceCollection
    {
        $users = User::query()
            ->when($request->filled('search'), function ($query) use ($request): void {
                $search = trim((string) $request->input('search'));
                $query->where(fn ($query) => $query
                    ->where('name', 'like', "%{$search}%")
                    ->orWhere('email', 'like', "%{$search}%")
                    ->orWhere('phone', 'like', "%{$search}%")
                    ->orWhere('department', 'like', "%{$search}%"));
            })
            ->when($request->filled('role'), fn ($query) => $query->where('role', $request->input('role')))
            ->latest()
            ->paginate(min(100, max(1, $request->integer('per_page', 20))))
            ->withQueryString();

        return UserResource::collection($users);
    }

    public function store(UserRequest $request): JsonResponse
    {
        return (new UserResource(User::query()->create($request->validated())))
            ->response()
            ->setStatusCode(201);
    }

    public function show(User $user): UserResource
    {
        return new UserResource($user);
    }

    public function update(UserRequest $request, User $user): UserResource
    {
        $data = $request->validated();

        if (blank($data['password'] ?? null)) {
            unset($data['password']);
        }

        if ($request->user()->is($user) && (! $data['is_active'] || $data['role'] !== 'admin')) {
            abort(422, 'Admin tidak dapat menonaktifkan atau menurunkan role akun sendiri.');
        }

        $user->update($data);

        return new UserResource($user->fresh());
    }

    public function destroy(Request $request, User $user)
    {
        abort_if($request->user()->is($user), 422, 'Anda tidak dapat menghapus akun sendiri.');
        abort_if(
            $user->role === 'admin'
                && $user->is_active
                && User::query()->where('role', 'admin')->where('is_active', true)->count() <= 1,
            422,
            'Minimal harus ada satu admin aktif.'
        );

        $user->delete();

        return response()->noContent();
    }
}
