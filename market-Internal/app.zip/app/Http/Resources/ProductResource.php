<?php

namespace App\Http\Resources;

use App\Models\ProductVariant;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class ProductResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $variants = $this->relationLoaded('variants') ? $this->variants->values() : collect();
        $activeVariants = $variants->where('is_active', true)->values();
        $defaultVariant = $activeVariants->firstWhere('is_default', true) ?? $activeVariants->first();
        $prices = $activeVariants->pluck('price')->map(fn ($price) => (float) $price);
        $rawImages = is_array($this->images) ? $this->images : [];
        $images = collect($rawImages)
            ->filter(fn ($path) => is_string($path) && filled($path))
            ->map(fn ($path) => [
                'path' => $path,
                'url' => $this->url($path),
            ])
            ->values();
        $firstImage = $images->first();

        return [
            'id' => $this->id,
            'category_id' => $this->category_id,
            'category' => $this->whenLoaded('category', fn () => new CategoryResource($this->category)),
            'name' => $this->name,
            'slug' => $this->slug,
            'type' => $this->type,
            'description' => $this->description,
            'brand' => $this->brand,
            'images' => $images->all(),
            'image_urls' => $images->pluck('url')->filter()->values()->all(),
            'thumbnail' => $firstImage['url'] ?? null,
            'variants' => $variants
                ->map(fn (ProductVariant $variant) => $this->variant($variant))
                ->values()
                ->all(),
            'default_variant' => $defaultVariant ? $this->variant($defaultVariant) : null,
            'has_multiple_variants' => $activeVariants->count() > 1
                || $activeVariants->contains(fn ($variant) => count($variant->attributes ?? []) > 0),
            'price' => $defaultVariant ? (float) $defaultVariant->price : 0,
            'price_min' => $prices->min() ?? 0,
            'price_max' => $prices->max() ?? 0,
            'available' => $activeVariants->contains(fn ($variant) => $variant->available),
            'rating' => (float) $this->rating,
            'review_count' => (int) $this->review_count,
            'status' => $this->status,
            'is_featured' => (bool) $this->is_featured,
            'is_active' => (bool) $this->is_active,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }

    private function variant(ProductVariant $variant): array
    {
        return [
            'id' => $variant->id,
            'product_id' => $variant->product_id,
            'sku' => $variant->sku,
            'name' => $variant->name,
            'price' => (float) $variant->price,
            'attributes' => array_values(is_array($variant->attributes) ? $variant->attributes : []),
            'track_stock' => (bool) $variant->track_stock,
            'stock' => $variant->stock,
            'is_default' => (bool) $variant->is_default,
            'is_active' => (bool) $variant->is_active,
            'available' => (bool) $variant->available,
        ];
    }

    private function url(?string $path): ?string
    {
        if (! $path) {
            return null;
        }

        return str_starts_with($path, 'http://') || str_starts_with($path, 'https://')
            ? $path
            : Storage::disk('public')->url($path);
    }
}
