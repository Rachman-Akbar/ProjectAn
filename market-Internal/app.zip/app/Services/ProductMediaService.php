<?php

namespace App\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;

class ProductMediaService
{
    public function prepare(array $existingPaths, array $keptPaths, array $files): array
    {
        $existing = collect($existingPaths)
            ->filter(fn ($path) => is_string($path) && $path !== '')
            ->unique()
            ->values();

        $kept = collect($keptPaths)
            ->filter(fn ($path) => is_string($path) && $existing->contains($path))
            ->unique()
            ->values();

        $stored = collect($files)
            ->filter(fn ($file) => $file instanceof UploadedFile)
            ->map(fn (UploadedFile $file) => $file->store('products', 'public'))
            ->values();

        return [
            'paths' => $kept->concat($stored)->values()->all(),
            'new_paths' => $stored->all(),
            'removed_paths' => $existing->diff($kept)->values()->all(),
        ];
    }

    public function deleteMany(array $paths): void
    {
        collect($paths)->each(fn ($path) => $this->delete((string) $path));
    }

    private function delete(string $path): void
    {
        if ($path === '' || str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) {
            return;
        }

        Storage::disk('public')->delete($path);
    }
}
